# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

You can Report vulnerabilities through the
[discord server](https://discord.gg/shittylist) or by DM'ing Raily
(iRaily#1230), BlueStone (Bluestone.#1449), Electro (Electro#0457) or
Prometheus(Prometheus#9463). Responses to vulnerability reports usually take
around 3 hours to more than a day, depending on how difficult fixing a
vulnerability is.
